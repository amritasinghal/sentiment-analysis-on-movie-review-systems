import tkinter as tk
from tkinter import messagebox
import csv
import os

def submit_review():
    movie = movie_entry.get().strip()
    review = review_entry.get("1.0", tk.END).strip()
    
    if not movie or not review:
        messagebox.showwarning("Input Error", "Please enter both movie name and review!")
        return
    
    file_exists = os.path.isfile('movie_reviews.csv')
    
    with open('movie_reviews.csv', 'a', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['Movie', 'Review']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        # Write header only if file does not exist
        if not file_exists:
            writer.writeheader()
        
        writer.writerow({'Movie': movie, 'Review': review})
    
    messagebox.showinfo("Success", f"Review for '{movie}' submitted!")
    
    # Clear inputs after submission
    movie_entry.delete(0, tk.END)
    review_entry.delete("1.0", tk.END)

def show_sentiment_distribution():
    # Placeholder for sentiment distribution logic
    messagebox.showinfo("Sentiment", "Sentiment distribution feature not implemented yet.")

root = tk.Tk()
root.title("Movie Review Sentiment Analyzer")

# Movie name label and entry
tk.Label(root, text="Movie Name:").pack(pady=(20, 0))
movie_entry = tk.Entry(root, width=40)
movie_entry.pack(pady=(0, 10))

# Review label and text box
tk.Label(root, text="Review:").pack()
review_entry = tk.Text(root, width=50, height=5)
review_entry.pack(pady=(0, 10))
tk.Label(root, text="Movie Name:").pack(pady=(20, 0))
movie_entry = tk.Entry(root, width=40)
movie_entry.pack(pady=(0, 10))

tk.Label(root, text="Review:").pack()
review_text = tk.Text(root, width=40, height=5)
review_text.pack(pady=(0, 10))

# Submit and show sentiment buttons
tk.Button(root, text="Submit Review", command=submit_review).pack(pady=5)
tk.Button(root, text="Show Sentiment Distribution", command=show_sentiment_distribution).pack(pady=5)

root.mainloop()
